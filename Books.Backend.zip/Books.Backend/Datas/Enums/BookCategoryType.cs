﻿namespace Books.Backend.Datas.Enums
{
    public enum BookCategoryType 
    {
        Mystery, Thriller, Romance, Science_Fiction, Fantasy, Historical_Fiction, Literary_Fiction,
        Biography, Autobiography, Self_Help, Personal_Development, History, Science, Nature, Business, Economics, Cookbooks,
        Encyclopedias, Dictionaries, Atlases_and_Maps, Picture_Books, MiddleGrade_Books, Young_Adult,
        Christianity, Islam, Buddhism,
        Travel_Guides
    }
}
